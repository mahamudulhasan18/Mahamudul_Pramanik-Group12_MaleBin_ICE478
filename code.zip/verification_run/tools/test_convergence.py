"""
Real (non-FAST) convergence test on the synthetic dataset.

Purpose: prove that ByteAttnNet actually LEARNS and is competitive with a
like-for-like from-scratch baseline, and that the ablation switches move the
number in a measurable way. Without this, a clean nbconvert run only proves the
plumbing works, not the model.
"""
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "code" / "common"))
SP = Path(os.environ.get("MALEBIN_WORK", ".")).resolve()

import malebin_common as M

M.CFG.out_dir = str(SP / "convout")
M.CFG.__post_init__()
M.CFG.img_size = 96
M.CFG.cache_size = 128
M.CFG.epochs = 22
M.CFG.batch_size = 32
M.CFG.num_workers = 0
M.CFG.amp = False
M.CFG.patience = 8
M.CFG.lr = 1e-3
M.set_seed(0)

df = M.scan_index(SP / "fake_malebin")
CLASS_NAMES = sorted(df.family.unique())
K = len(CLASS_NAMES)
imgs = M.load_images(df, side=M.CFG.cache_size, workers=0)
groups = M.build_dedup_groups(imgs, df)
tr, va, te = M.grouped_holdout_split(df, groups)

rows = []


def run(tag, model, aug="byte", in_ch=1, epochs=None):
    M.set_seed(0)
    t0 = time.time()
    ltr, lva, lte = M.make_loaders(imgs, df, tr, va, te, aug=aug, in_channels=in_ch)
    _, hist, s = M.train_model(model, ltr, lva, K, tag=tag, verbose=False,
                               epochs=epochs)
    y, p, pr = M.predict(model, lte)
    mm = M.full_metrics(y, p, pr, CLASS_NAMES, name=tag)
    rows.append(dict(model=tag, params=s["params"],
                     val_macro_f1=s["best_val_macro_f1"],
                     test_acc=mm["accuracy"], test_macro_f1=mm["f1_macro"],
                     test_weighted_f1=mm["f1_weighted"],
                     epochs=s["epochs_run"], secs=round(time.time() - t0, 1)))
    print(f"  {tag:<34s} val-F1 {s['best_val_macro_f1']:.4f}  "
          f"test macro-F1 {mm['f1_macro']:.4f}  acc {mm['accuracy']:.4f}  "
          f"({s['epochs_run']} ep, {time.time()-t0:.0f}s)")
    return mm, np.asarray(p), np.asarray(y)


M.banner("A · Does ByteAttnNet learn at all, and beat a like-for-like baseline?")
mm_simple, p_simple, y_te = run("SimpleCNN (scratch, no attn)",
                                M.SimpleCNN(K, in_ch=1, width=24))
mm_full, p_full, _ = run("ByteAttnNet (cbam+coord)",
                         M.ByteAttnNet(K, channels=(32, 64, 128, 192)))

M.banner("B · Do the ablation switches move the number?")
abl = {}
for att in ["none", "se", "cbam", "coord", "cbam+coord"]:
    mm, _, _ = run(f"attn={att}", M.ByteAttnNet(K, channels=(32, 64, 128, 192),
                                                attention=att))
    abl[att] = mm["f1_macro"]
for extra, kw in [("no-multiscale", dict(multiscale=False)),
                  ("pool=gap", dict(pool="gap")),
                  ("no-batchnorm", dict(use_bn=False))]:
    mm, _, _ = run(extra, M.ByteAttnNet(K, channels=(32, 64, 128, 192), **kw))
    abl[extra] = mm["f1_macro"]

M.banner("C · Augmentation policy")
for a in ["none", "naive", "byte"]:
    mm, _, _ = run(f"aug={a}", M.ByteAttnNet(K, channels=(32, 64, 128, 192)), aug=a)

tbl = pd.DataFrame(rows)
print()
print(tbl.to_string(index=False))
tbl.to_csv(SP / "convergence_results.csv", index=False)

M.banner("D · Statistical machinery on REAL predictions")
r = M.mcnemar_test(y_te, p_full, p_simple, "ByteAttnNet", "SimpleCNN")

print("\n" + "=" * 74)
ok = True
if mm_full["f1_macro"] < 0.25:
    print(f"FAIL: ByteAttnNet macro-F1 {mm_full['f1_macro']:.4f} -- it is not learning")
    ok = False
else:
    print(f"OK  : ByteAttnNet learns (test macro-F1 {mm_full['f1_macro']:.4f})")
spread = max(abl.values()) - min(abl.values())
print(f"OK  : ablation spread = {spread:.4f} macro-F1 across "
      f"{len(abl)} variants -> the switches do something"
      if spread > 0.02 else
      f"WARN: ablation spread only {spread:.4f} -- switches barely matter here")
print(f"INFO: attention ranking -> "
      + ", ".join(f"{k}={v:.3f}" for k, v in sorted(abl.items(), key=lambda t: -t[1])))
sys.exit(0 if ok else 1)
