"""Rigid test of malebin_common.py against the synthetic dataset."""
import os
import sys
import traceback
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "code" / "common"))
SP = Path(os.environ.get("MALEBIN_WORK", ".")).resolve()

FAILED = []


def check(name, fn):
    try:
        fn()
        print(f"PASS  {name}")
    except Exception as e:
        FAILED.append(name)
        print(f"FAIL  {name}: {type(e).__name__}: {e}")
        traceback.print_exc(limit=4)


import malebin_common as M  # noqa: E402

M.CFG.out_dir = str(SP / "testout")
M.CFG.__post_init__()
M.CFG.img_size = 64
M.CFG.cache_size = 64
M.CFG.epochs = 3
M.CFG.batch_size = 32
M.CFG.num_workers = 0
M.CFG.amp = False
M.CFG.patience = 3
M.set_seed(0)

# ---------------------------------------------------------------- discovery
root = None
df = None


def t_discover():
    global root, df
    root = M.find_dataset_root(str(SP / "fake_malebin"))
    assert root.name == "fake_malebin", root
    df = M.scan_index(root)
    assert len(df) == 714, len(df)
    assert df.family.nunique() == 39
    assert df.is_malimg.sum() > 0
    assert df.loc[df.is_malimg, "family"].nunique() == 25, \
        df.loc[df.is_malimg, "family"].nunique()


check("find_dataset_root + scan_index (39 classes, 25 Malimg matched)", t_discover)


def t_discover_nested():
    """A wrapper folder above the class folders must also resolve."""
    nest = SP / "nested_ds"
    if not nest.exists():
        (nest / "MaleBin_v1").mkdir(parents=True, exist_ok=True)
        for fam in sorted(p.name for p in (SP / "fake_malebin").iterdir())[:3]:
            tgt = nest / "MaleBin_v1" / fam
            tgt.mkdir(parents=True, exist_ok=True)
            for k, src in enumerate(sorted((SP / "fake_malebin" / fam).iterdir())[:3]):
                tgt.joinpath(src.name).write_bytes(src.read_bytes())
    r = M.find_dataset_root(str(nest))
    assert r.name == "MaleBin_v1", r


check("find_dataset_root descends through a wrapper folder", t_discover_nested)

# ---------------------------------------------------------------- loading
imgs = None


def t_load():
    global imgs
    imgs = M.load_images(df, side=64, workers=0)
    assert imgs.shape == (714, 64, 64), imgs.shape
    assert imgs.dtype == np.uint8
    assert imgs.max() > 200 and imgs.min() < 40


check("load_images -> uint8 (N,64,64) cache", t_load)


def t_load_parallel():
    a = M.load_images(df.head(120), side=32, workers=3, verbose=False)
    b = M.load_images(df.head(120), side=32, workers=0, verbose=False)
    assert np.array_equal(a, b), "parallel and serial decode disagree"


check("load_images parallel == serial", t_load_parallel)

# ---------------------------------------------------------------- dedup / split
groups = None


def t_dedup():
    global groups
    groups = M.build_dedup_groups(imgs, df)
    n_g = groups.max() + 1
    assert n_g < len(df), "no near-duplicates collapsed -- dhash is not working"
    assert n_g > 39, "collapsed too aggressively"
    # every group must sit inside one family
    import pandas as pd
    gf = pd.DataFrame({"g": groups, "f": df.family.values})
    assert (gf.groupby("g").f.nunique() > 1).sum() == 0


check("build_dedup_groups collapses near-duplicates, never crosses families", t_dedup)


def t_dhash_identical():
    """Identical images must get identical hashes; a shifted one must not."""
    a = imgs[:1]
    h1 = M._dhash128(np.repeat(a, 3, axis=0))
    assert (h1[0] == h1[1]).all() and (h1[0] == h1[2]).all()
    b = np.roll(a, 20, axis=1)
    h2 = M._dhash128(np.concatenate([a, b]))
    d = M._POPCOUNT[np.bitwise_xor(h2[0], h2[1])].sum()
    assert d > 6, f"a 20-row shift should NOT look like a duplicate (d={d})"


check("_dhash128 is stable and discriminative", t_dhash_identical)


tr = va = te = None


def t_split():
    global tr, va, te
    tr, va, te = M.grouped_holdout_split(df, groups)
    assert len(set(tr) & set(va)) == 0 and len(set(tr) & set(te)) == 0
    assert len(tr) + len(va) + len(te) == len(df)
    # the real point: no duplicate group may straddle subsets
    M.assert_no_group_leak({"train": tr, "val": va, "test": te}, groups)
    y = df.label.values
    assert len(set(y[te])) >= 35, f"test set lost classes: {len(set(y[te]))}"


check("grouped_holdout_split is leakage-free and keeps all classes", t_split)


def t_leak_detector_fires():
    """The guard must actually raise when a group is shared."""
    bad_a = np.array([0, 1, 2, 3])
    bad_b = np.array([3, 4, 5])
    try:
        M.assert_no_group_leak({"a": bad_a, "b": bad_b}, groups)
    except AssertionError:
        return
    raise RuntimeError("assert_no_group_leak did NOT fire on a real leak")


check("assert_no_group_leak raises on an actual leak", t_leak_detector_fires)


def t_kfold():
    folds = M.grouped_kfold(df, groups, n_folds=5)
    assert len(folds) == 5
    seen = set()
    for k, (a, b) in enumerate(folds):
        assert not (set(groups[a]) & set(groups[b])), f"fold {k} leaks"
        seen |= set(b.tolist())
    assert len(seen) == len(df), "folds do not cover the dataset exactly once"


check("grouped_kfold: 5 disjoint leakage-free folds covering the data", t_kfold)

# ---------------------------------------------------------------- dataset / aug
def t_dataset():
    ds = M.ByteImageDataset(imgs, df.label.values, tr, out_size=64, aug="byte")
    x, y = ds[0]
    assert tuple(x.shape) == (1, 64, 64), x.shape
    assert abs(float(x.mean())) < 0.2 and abs(float(x.std()) - 1) < 0.4, (x.mean(), x.std())
    ds3 = M.ByteImageDataset(imgs, df.label.values, tr, out_size=32, in_channels=3)
    x3, _ = ds3[0]
    assert tuple(x3.shape) == (3, 32, 32), x3.shape
    # augmentation must actually change the tensor
    ds.set_epoch(1)
    xs = [ds[0][0] for _ in range(6)]
    import torch
    assert any(not torch.allclose(xs[0], v) for v in xs[1:]), "aug='byte' is a no-op"
    dsn = M.ByteImageDataset(imgs, df.label.values, tr, out_size=64, aug="none")
    assert torch.allclose(dsn[0][0], dsn[0][0])


check("ByteImageDataset: shapes, normalisation, 3-ch repeat, augmentation", t_dataset)


def t_aug_naive():
    ds = M.ByteImageDataset(imgs, df.label.values, tr, out_size=64, aug="naive")
    x, _ = ds[0]
    assert tuple(x.shape) == (1, 64, 64)


check("aug='naive' path runs (needed for the ablation)", t_aug_naive)

# ---------------------------------------------------------------- models
def t_models():
    import torch
    x = torch.randn(2, 1, 64, 64)
    for a in ["none", "se", "spatial", "cbam", "coord", "cbam+coord"]:
        m = M.ByteAttnNet(39, attention=a)
        assert tuple(m(x).shape) == (2, 39)
    for p in ["gap", "gem", "gap+gmp"]:
        assert tuple(M.ByteAttnNet(39, pool=p)(x).shape) == (2, 39)
    assert tuple(M.ByteAttnNet(39, multiscale=False)(x).shape) == (2, 39)
    assert tuple(M.ByteAttnNet(39, use_bn=False)(x).shape) == (2, 39)
    assert tuple(M.ByteAttnNet(39, depth=(2, 2, 2, 2))(x).shape) == (2, 39)
    assert tuple(M.ByteAttnNet(39, channels=(16, 32, 64, 96))(x).shape) == (2, 39)


check("ByteAttnNet: all ablation switches produce correct output shape", t_models)


def t_baselines():
    import torch
    for nm in ["SimpleCNN", "ResNet18", "MobileNetV3-Small"]:
        m, ic = M.build_baseline(nm, 39, pretrained=False)
        x = torch.randn(2, ic, 64, 64)
        assert tuple(m(x).shape) == (2, 39), (nm, m(x).shape)
        assert M.gradcam_target(m) is not None
    try:
        M.build_baseline("Nope", 39)
    except ValueError:
        pass
    else:
        raise RuntimeError("unknown baseline should raise")


check("build_baseline: torchvision heads re-wired to 39 classes", t_baselines)

# ---------------------------------------------------------------- training
state = hist = summ = None


def t_train():
    global state, hist, summ
    ltr, lva, lte = M.make_loaders(imgs, df, tr, va, te, batch_size=32,
                                   aug="byte", out_size=64)
    m = M.ByteAttnNet(39, channels=(16, 32, 64, 96))
    state, hist, summ = M.train_model(m, ltr, lva, 39, epochs=3, tag="smoke",
                                     save_path=M.CFG.mdl("smoke.pth"))
    assert len(hist) >= 1 and "val_macro_f1" in hist.columns
    assert summ["best_val_macro_f1"] >= 0
    assert Path(M.CFG.mdl("smoke.pth")).exists()
    y, p, pr = M.predict(m, lte)
    assert len(y) == len(te) and pr.shape == (len(te), 39)
    assert abs(pr.sum(1).mean() - 1) < 1e-4


check("train_model runs, early-stops, checkpoints; predict returns probs", t_train)


def t_schedulers_optimizers():
    ltr, lva, _ = M.make_loaders(imgs, df, tr[:96], va[:64], None,
                                 batch_size=32, out_size=32)
    for sch in ["cosine", "plateau", "step", "none"]:
        for opt in ["adamw", "sgd"]:
            m = M.ByteAttnNet(39, channels=(8, 16, 24, 32))
            M.train_model(m, ltr, lva, 39, epochs=2, scheduler=sch, optimizer=opt,
                          tag=f"{sch}/{opt}", verbose=False)


check("every scheduler x optimizer combination trains (ablation grid)", t_schedulers_optimizers)


def t_class_weights():
    w = M.class_weights_from(np.array([0, 0, 0, 0, 1, 2]), 3)
    assert w[1] > w[0] and abs(float(w.mean()) - 1) < 1e-5, w


check("class_weights_from: inverse frequency, mean 1", t_class_weights)

# ---------------------------------------------------------------- metrics
def t_metrics():
    ltr, lva, lte = M.make_loaders(imgs, df, tr, va, te, batch_size=64, out_size=64)
    m = M.ByteAttnNet(39, channels=(16, 32, 64, 96))
    m.load_state_dict(state)
    y, p, pr = M.predict(m, lte)
    names = sorted(df.family.unique())
    mm = M.full_metrics(y, p, pr, names, name="ByteAttnNet")
    for k in ["accuracy", "f1_macro", "f1_weighted", "recall_macro",
              "roc_auc_macro_ovr", "mcc", "balanced_accuracy"]:
        assert k in mm, k
        assert not np.isnan(mm[k]), k
    assert mm["_confusion"].shape == (39, 39)
    assert len(mm["_report_df"]) >= 39
    t = M.metrics_frame([mm, dict(mm, model="other")])
    assert list(t.columns)[:3] == ["model", "accuracy", "balanced_accuracy"]
    assert len(t) == 2
    ms = M.measure_inference_ms(m, lte, n_batches=3)
    assert ms > 0


check("full_metrics / metrics_frame / measure_inference_ms", t_metrics)


def t_metrics_missing_class():
    """A class absent from the test set must not crash AUC."""
    y = np.array([0, 0, 1, 1, 2])
    p = np.array([0, 1, 1, 1, 2])
    pr = np.eye(4)[np.array([0, 1, 1, 1, 2])] * 0.7 + 0.075
    mm = M.full_metrics(y, p, pr, ["a", "b", "c", "d"], name="x")
    assert not np.isnan(mm["f1_macro"])


check("full_metrics survives a class missing from the test set", t_metrics_missing_class)


def t_plots():
    import matplotlib
    matplotlib.use("Agg")
    ltr, lva, lte = M.make_loaders(imgs, df, tr, va, te, batch_size=64, out_size=64)
    m = M.ByteAttnNet(39, channels=(16, 32, 64, 96))
    m.load_state_dict(state)
    y, p, pr = M.predict(m, lte)
    names = sorted(df.family.unique())
    mm = M.full_metrics(y, p, pr, names)
    M.plot_history(hist, save=M.CFG.fig("t_hist.png"))
    M.plot_confusion(mm["_confusion"], names, save=M.CFG.fig("t_cm.png"))
    f, auc = M.plot_roc_ovr(y, pr, names, save=M.CFG.fig("t_roc.png"))
    f2, ap = M.plot_pr_ovr(y, pr, names, save=M.CFG.fig("t_pr.png"))
    assert 0 <= auc <= 1 and 0 <= ap <= 1
    for n in ["t_hist.png", "t_cm.png", "t_roc.png", "t_pr.png"]:
        assert Path(M.CFG.fig(n)).exists(), n


check("all four required plot helpers write files", t_plots)

# ---------------------------------------------------------------- statistics
def t_mcnemar():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 5, 600)
    a = y.copy(); b = y.copy()
    a[rng.choice(600, 30, replace=False)] = 9      # A wrong 30x
    b[rng.choice(600, 90, replace=False)] = 9      # B wrong ~90x
    r = M.mcnemar_test(y, a, b, "A", "B", verbose=False)
    assert r["p_value"] < 0.05 and r["better"] == "A", r
    # identical models -> not significant
    r2 = M.mcnemar_test(y, a, a.copy(), verbose=False)
    assert r2["p_value"] == 1.0 and r2["n_discordant"] == 0
    # small discordance -> exact binomial branch
    a2 = y.copy(); a2[:3] = 9
    b2 = y.copy(); b2[3:8] = 9
    r3 = M.mcnemar_test(y, a2, b2, verbose=False)
    assert "exact" in r3["variant"], r3["variant"]


check("mcnemar_test: chi2 branch, degenerate branch, exact branch", t_mcnemar)


def t_wilcoxon():
    a = [0.91, 0.93, 0.92, 0.94, 0.925]
    b = [0.88, 0.89, 0.87, 0.90, 0.885]
    r = M.wilcoxon_folds(a, b, "prop", "base", verbose=False)
    assert r["mean_diff"] > 0 and r["n_folds"] == 5
    assert r["p_value"] <= 0.0625 + 1e-9
    assert "cohens_d_paired" in r and "paired_t_p_value" in r
    r0 = M.wilcoxon_folds(a, a, verbose=False)
    assert r0["p_value"] == 1.0


check("wilcoxon_folds: paired test + t-test + effect size + zero-diff guard", t_wilcoxon)


def t_friedman():
    rng = np.random.default_rng(1)
    S = np.stack([rng.normal(0.93, 0.01, 5), rng.normal(0.90, 0.01, 5),
                  rng.normal(0.86, 0.01, 5), rng.normal(0.80, 0.01, 5)], axis=1)
    r = M.friedman_nemenyi(S, ["prop", "b1", "b2", "b3"], verbose=False)
    assert r["p_value"] < 0.05
    assert min(r["average_ranks"], key=r["average_ranks"].get) == "prop"
    assert r["critical_difference"] > 0 and len(r["pairwise"]) == 6


check("friedman_nemenyi: ranks, CD, pairwise table", t_friedman)

# ---------------------------------------------------------------- XAI
def t_gradcam():
    import torch
    m = M.ByteAttnNet(39, channels=(16, 32, 64, 96))
    m.load_state_dict(state)
    ds = M.ByteImageDataset(imgs, df.label.values, te, out_size=64, aug="none")
    x, y = ds[0]
    cam_obj = M.GradCAM(m)
    cam, ci, pr = cam_obj(x[None], plus_plus=False)
    assert cam.shape == (64, 64) and 0 <= cam.min() and cam.max() <= 1.0 + 1e-6
    cam2, _, _ = cam_obj(x[None], class_idx=int(y), plus_plus=True)
    assert cam2.shape == (64, 64)
    cam_obj.remove()
    b = M.cam_to_byte_offsets(cam, img_width_px=64)
    assert len(b["row_profile"]) == 64 and len(b["bands"]) >= 1
    assert 0 <= b["bands"][0]["file_pct_from"] <= 100


check("GradCAM + Grad-CAM++ + cam_to_byte_offsets", t_gradcam)


def t_gradcam_baselines():
    import torch
    for nm in ["SimpleCNN", "ResNet18"]:
        m, ic = M.build_baseline(nm, 39, pretrained=False)
        g = M.GradCAM(m)
        cam, ci, p = g(torch.randn(1, ic, 64, 64))
        assert cam.shape == (64, 64)
        g.remove()


check("GradCAM works on the baselines too", t_gradcam_baselines)


def t_occlusion():
    import torch
    m = M.ByteAttnNet(39, channels=(16, 32, 64, 96))
    m.load_state_dict(state)
    ds = M.ByteImageDataset(imgs, df.label.values, te, out_size=64, aug="none")
    x, y = ds[0]
    drops, base = M.occlusion_by_row_band(m, x[None], int(y), n_bands=8)
    assert drops.shape == (8,) and 0 <= base <= 1


check("occlusion_by_row_band returns per-band causal drops", t_occlusion)


def t_lime():
    m = M.ByteAttnNet(39, channels=(16, 32, 64, 96))
    m.load_state_dict(state)
    raw = imgs[int(te[0])]
    ex = M.lime_explain(m, raw, sorted(df.family.unique()), in_channels=1,
                        out_size=64, num_samples=60, segments="grid")
    lab = ex.top_labels[0]
    from skimage.segmentation import mark_boundaries  # noqa
    im, mask = ex.get_image_and_mask(lab, positive_only=True, num_features=5,
                                     hide_rest=False)
    assert mask.shape == raw.shape, (mask.shape, raw.shape)


check("lime_explain with row-band segmentation", t_lime)


def t_lime_quickshift():
    m = M.ByteAttnNet(39, channels=(16, 32, 64, 96))
    m.load_state_dict(state)
    ex = M.lime_explain(m, imgs[int(te[0])], sorted(df.family.unique()),
                        in_channels=1, out_size=64, num_samples=40,
                        segments="quickshift")
    assert len(ex.top_labels) >= 1


check("lime_explain naive quickshift path (for the honest comparison)", t_lime_quickshift)

# ---------------------------------------------------------------- scope / refs
def t_scope():
    M.CFG.eval_scope = "malimg25"
    d25 = M.tag_malimg_subset(df)
    assert d25.family.nunique() == 25 and d25.label.max() == 24
    M.CFG.eval_scope = "malebin39"
    d39 = M.tag_malimg_subset(df)
    assert d39.family.nunique() == 39 and len(d39) == len(df)


check("tag_malimg_subset re-encodes labels for both scopes", t_scope)


def t_related():
    t = M.related_work_frame()
    assert len(t) >= 5, len(t)
    assert t.year.between(2022, 2026).all()
    assert M.related_work_frame(only_comparable=True).comparable.all()
    for sc in ["malimg25", "malebin39"]:
        b = M.best_comparable_target(sc)
        assert b["value"] > 50 and b["caveat"]


check("RELATED_WORK: >=5 papers 2022-2026 + Pillar-A target per scope", t_related)


def t_json():
    p = M.save_json({"a": np.float32(1.5), "b": np.arange(3), "c": Path("x")},
                    M.CFG.art("t.json"))
    d = M.load_json(p)
    assert d["a"] == 1.5 and d["b"] == [0, 1, 2]


check("save_json handles numpy / Path types", t_json)

# ---------------------------------------------------------------- leakage demo
def t_leakage_demo():
    """CFG.group_by_duplicates=False must produce per-image groups."""
    M.CFG.group_by_duplicates = False
    g = M.build_dedup_groups(imgs[:50], df.head(50), verbose=False)
    assert len(set(g)) == 50
    M.CFG.group_by_duplicates = True


check("group_by_duplicates=False -> ungrouped (leakage demo mode)", t_leakage_demo)

print("\n" + "=" * 70)
if FAILED:
    print(f"{len(FAILED)} FAILURE(S): {FAILED}")
    sys.exit(1)
print("ALL CORE TESTS PASSED")
