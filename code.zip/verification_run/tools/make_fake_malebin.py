"""
Build a synthetic dataset that mimics MaleBin's *shape* so the notebooks can be
executed end-to-end offline:
  * 39 class folders -- the 25 real Malimg family names + 14 extra names
  * 256x256 8-bit grayscale PNGs
  * per-family row-band structure (header / .text / .data / padding), so a CNN
    can actually learn something and metrics are not pure noise
  * deliberate near-duplicate variants inside families -> exercises the
    duplicate-grouping / leakage-control code path
  * imbalanced per-class counts
"""
import sys
from pathlib import Path
import numpy as np
from PIL import Image

MALIMG_25 = [
    "Adialer.C", "Agent.FYI", "Allaple.A", "Allaple.L", "Alueron.gen!J",
    "Autorun.K", "C2LOP.gen!g", "C2LOP.P", "Dialplatform.B", "Dontovo.A",
    "Fakerean", "Instantaccess", "Lolyda.AA1", "Lolyda.AA2", "Lolyda.AA3",
    "Lolyda.AT", "Malex.gen!J", "Obfuscator.AD", "Rbot!gen", "Skintrim.N",
    "Swizzor.gen!E", "Swizzor.gen!I", "VB.AT", "Wintrim.BX", "Yuner.A",
]
EXTRA_14 = ["AgentTesla", "Amadey", "AsyncRAT", "Emotet", "Formbook", "GuLoader",
            "Heodo", "Loki", "NanoCore", "Quakbot", "RedLine", "Remcos",
            "Smoke Loader", "Trickbot"]
FAMILIES = MALIMG_25 + EXTRA_14

S = 256


def family_template(fi: int, rng) -> np.ndarray:
    """A byte-plot-like image: banded sections with family-specific texture."""
    img = np.zeros((S, S), dtype=np.float32)
    n_bands = 3 + fi % 4
    edges = np.sort(rng.choice(np.arange(16, S - 16), n_bands - 1, replace=False))
    edges = np.concatenate([[0], edges, [S]])
    for b in range(len(edges) - 1)  :
        r0, r1 = edges[b], edges[b + 1]
        kind = (fi + b) % 5
        h = r1 - r0
        if kind == 0:                          # dense code-like texture
            blk = rng.integers(40, 200, size=(h, S))
        elif kind == 1:                        # repeating opcode pattern
            period = 4 + (fi % 11)
            base = rng.integers(0, 256, size=(1, period)).astype(np.float32)
            blk = np.tile(base, (h, S // period + 1))[:, :S]
            blk += rng.normal(0, 8, size=(h, S))
        elif kind == 2:                        # high-entropy (packed) region
            blk = rng.integers(0, 256, size=(h, S))
        elif kind == 3:                        # zero padding
            blk = np.full((h, S), 0.0) + rng.normal(0, 2, size=(h, S))
        else:                                  # ascii / string table
            blk = rng.integers(32, 127, size=(h, S))
        img[r0:r1] = blk
    # a family-specific vertical stripe signature (import table column)
    col = 20 + (fi * 7) % 200
    img[:, col:col + 3] = 250
    return np.clip(img, 0, 255)


def variant(base: np.ndarray, rng, strength: float) -> np.ndarray:
    """Polymorphic variant: shifted sections + noise + a patched region."""
    a = np.roll(base, int(rng.integers(-int(24 * strength), int(24 * strength) + 1)), axis=0)
    a = a + rng.normal(0, 6 * strength, size=a.shape)
    if rng.random() < 0.5 * strength:
        h = int(rng.integers(8, 40))
        r0 = int(rng.integers(0, S - h))
        a[r0:r0 + h] = rng.integers(0, 256, size=(h, S))
    return np.clip(a, 0, 255).astype(np.uint8)


def main(out_dir: str, per_class_min=10, per_class_max=26, seed=7):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    total = 0
    for fi, fam in enumerate(FAMILIES):
        d = out / fam
        d.mkdir(parents=True, exist_ok=True)
        n = int(rng.integers(per_class_min, per_class_max + 1))
        base = family_template(fi, rng)
        # n images arranged in a few "binary lineages": each lineage produces
        # 1-4 NEAR-DUPLICATE variants, which is exactly the leakage risk.
        i = 0
        while i < n:
            lineage = variant(base, rng, strength=1.0)
            k = min(int(rng.integers(1, 5)), n - i)
            for j in range(k):
                arr = lineage if j == 0 else variant(lineage.astype(np.float32),
                                                     rng, strength=0.06)
                Image.fromarray(arr, mode="L").save(d / f"{fam}_{i:04d}.png",
                                                    optimize=False)
                i += 1
        total += n
    print(f"wrote {total} images across {len(FAMILIES)} families -> {out}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "./fake_malebin")
