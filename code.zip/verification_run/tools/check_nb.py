"""Report every error cell in the executed notebooks given as arguments."""
import sys
from pathlib import Path
import nbformat

total = 0
for f in sys.argv[1:]:
    p = Path(f)
    if not p.exists():
        print(f"!! missing {p}")
        total += 1
        continue
    nb = nbformat.read(str(p), as_version=4)
    errs = []
    for i, c in enumerate(nb.cells):
        if c.cell_type != "code":
            continue
        for o in c.get("outputs", []):
            if o.output_type == "error":
                errs.append((i, o))
    print(f"\n{'='*78}\n{p.name}: {len(errs)} error cell(s)")
    for i, o in errs:
        print("-" * 78)
        print(f"CELL {i}  {o.ename}: {o.evalue}")
        tb = [l for l in o.traceback if l.strip()]
        print("\n".join(tb[-10:]))
    total += len(errs)
print(f"\n### TOTAL ERROR CELLS: {total}")
sys.exit(1 if total else 0)
