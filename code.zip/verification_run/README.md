# verification_run/ — proof the code runs, **not** results

## Read this first

Everything in this folder was produced on a **local CPU** against a
**synthetic stand-in dataset**, in `MALEBIN_FAST=1` mode (64 px images, 2 epochs,
2 CV folds).

**The numbers in these notebooks are meaningless and must not be quoted
anywhere.** They come from fake images and two training epochs. Their only
purpose is to demonstrate that every cell of every notebook executes without
error, that the artifacts chain correctly between notebooks, and that the
statistical machinery produces sane output on real predictions.

The real results come from running the notebooks in `../code/` on Kaggle against
the real MaleBin dataset with a GPU. See `../README.md` §4.

---

## What was verified

### 1. `tools/test_core.py` — 31 unit tests on the shared library

All pass. Coverage:

| Area | Tests |
|---|---|
| Dataset discovery | flat layout; layout nested under a wrapper folder; 39 classes indexed; 25 Malimg families matched by name |
| Image loading | uint8 cache shape/dtype; parallel decode == serial decode |
| **Leakage control** | near-duplicates collapse; groups never span families; dHash stable on identical images and discriminative on a 20-row shift; grouped hold-out split is leak-free and keeps all classes; **the leak assertion actually fires on a real leak**; 5 grouped folds disjoint and covering |
| Dataset / augmentation | tensor shapes; per-image standardisation; 3-channel repeat; `aug='byte'` is not a no-op; `aug='naive'` path runs |
| Models | all 6 attention variants, all 3 pooling variants, `multiscale=False`, `use_bn=False`, depth and channel variants → correct output shape; torchvision baseline heads re-wired to 39 classes; unknown baseline raises |
| Training | trains, early-stops, checkpoints; `predict` returns valid probability rows; every scheduler × optimiser combination trains; class weights are inverse-frequency with mean 1 |
| Metrics | full metric set non-NaN; confusion matrix and per-class report shapes; comparison-table column order; inference timing; **survives a class missing from the test set** |
| Plots | all four required figure helpers write files |
| Statistics | McNemar χ² branch, degenerate branch (no discordant pairs) and exact-binomial branch; Wilcoxon with paired *t*-test, effect size and zero-difference guard; Friedman ranks + Nemenyi critical difference + pairwise table |
| XAI | Grad-CAM, Grad-CAM++, CAM→byte-offset conversion; Grad-CAM on the baselines; row-band occlusion; LIME with both segmentations |
| Misc | both `eval_scope` values re-encode labels; ≥5 related-work papers dated 2022–2026 with a Pillar-A target per scope; JSON writer handles numpy/Path; leakage-demo mode |

Two real portability bugs were found and fixed by this suite:

* `ndarray.ptp()` — **removed in NumPy 2.0**, which Kaggle uses. Replaced with
  `np.ptp(arr)`.
* `scipy.stats.wilcoxon(mode="exact")` — the `mode` keyword was renamed to
  `method` in SciPy 1.9 and removed in 1.12. Now tried in order with a fallback.

A third class of bug is now prevented at generation time: `nbtool.validate_code`
rejects any backslash-escaped quote in a code cell, because a backslash inside an
f-string expression is a **SyntaxError on Python 3.11** (Kaggle's version) even
though Python 3.12+ accepts it. It also `ast.parse`s every cell before writing.

### 2. `tools/test_convergence.py` — does the model actually learn?

A clean-up test at realistic settings (96 px, up to 22 epochs, full-width
channels) on the synthetic data. `convergence_results.csv` and
`convergence_log.txt` hold the output. Summary:

| Variant | test macro-F1 | test accuracy |
|---|---|---|
| SimpleCNN (scratch, no attention) | 0.9292 | 0.9786 |
| **ByteAttnNet (cbam+coord)** | **0.9487** | **1.0000** |
| `aug=byte` (ours) | 0.9365 | 0.9929 |
| `aug=none` | 0.8900 | 0.9500 |
| `aug=naive` (flips + rotations) | **0.7286** | 0.7786 |
| `no-batchnorm` | 0.8037 | 0.8571 |

Two things this establishes:

1. **ByteAttnNet trains and converges**, and beats the like-for-like from-scratch
   baseline. The architecture is not broken.
2. **The augmentation argument holds even on synthetic byte-plots.** The naive
   flip+rotate recipe costs **0.21 macro-F1** versus byte-aware augmentation.
   That is the Task-2b claim — flipping a byte-plot produces a file that cannot
   exist — showing up as a large measured penalty.

**What it does *not* establish:** anything about attention. The synthetic task
saturates (ByteAttnNet reaches 100 % accuracy), so `attn=none` and `attn=cbam`
tie with the full stack at the ceiling and the ordering among attention variants
is noise. Whether coordinate attention helps is an open question that only the
real 39-family dataset can answer — which is exactly what the Task-3a ablation is
built to measure, and why its markdown spells out all four possible outcomes
including "it contributed nothing".

### 3. `executed_notebooks/` — all five notebooks, end-to-end, 0 errors

Run in sequence from one working directory so artifacts chain the way they do
inside a single Kaggle session. Confirmed working:

* Notebook 2b **loaded notebook 2a's baseline table** from disk.
* Notebook 3a **loaded notebook 2a's per-sample test predictions** and ran McNemar
  against *both* baselines — and its assertion that the two notebooks used the
  **same test indices and the same labels** passed. That is the proof that the
  content-derived split is genuinely deterministic across notebooks, with no
  artifact passing required.
* Notebook 3b **loaded notebook 3a's `best.pth` checkpoint**.
* The standalone fallbacks were exercised too: in an earlier run where the
  notebooks sat in different directories, notebook 3a correctly detected the
  missing predictions and retrained the baseline so McNemar could still run.

Artifacts produced by the chain: 36 CSV/JSON/NPZ files, 46 figures, 5 checkpoints.

---

## The synthetic dataset

`tools/make_fake_malebin.py` builds a stand-in with MaleBin's *shape*:

* 39 class folders — the 25 real Malimg family names plus 14 modern-family names,
  so the `MALIMG_25` matching logic is genuinely exercised;
* 256×256 8-bit grayscale PNGs;
* per-family horizontal band structure (dense code-like texture, periodic
  patterns, high-entropy packed regions, zero padding, ASCII string tables) plus a
  family-specific vertical stripe — so a CNN has real structure to learn;
* deliberate **near-duplicate lineages**: each family's images are generated as
  1–4 variants of a shared parent, which is what exercises the duplicate-grouping
  and leakage-control code (it collapsed 714 images into 361 groups, 49.4 %);
* imbalanced per-class counts.

```bash
python tools/make_fake_malebin.py ./fake_malebin
export MALEBIN_FAST=1 MALEBIN_DATA_ROOT=$PWD/fake_malebin
python tools/test_core.py
python tools/test_convergence.py
```

`tools/check_nb.py <notebook.ipynb>...` reports every error cell in an executed
notebook; it exits non-zero if any exist.
